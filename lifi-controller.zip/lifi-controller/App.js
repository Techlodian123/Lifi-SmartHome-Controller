import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
} from 'react-native';

export default function App() {
  // --- Form & Status State (Dummy data for Phase 1) ---
  const [inputText, setInputText] = useState('');
  const [isConnected, setIsConnected] = useState(true);
  const [txStatus, setTxStatus] = useState('Idle');
  
  // Dummy received data packet
  const [receivedData, setReceivedData] = useState({
    type: 'location',
    name: 'IoT Laboratory',
    room: '204',
    floor: '2',
    beacon_id: 'LAB_01',
    message: 'Welcome to IoT Lab',
    timestamp: '10:42 AM',
  });

  // Simulated button click handler
  const handleSend = () => {
    if (!inputText.trim()) return;
    setTxStatus(`Transmitting: "${inputText}" via Li-Fi...`);
    
    // Simulate Pi acknowledgement
    setTimeout(() => {
      setTxStatus(`Sent: "${inputText}"`);
      setInputText('');
    }, 1200);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#0f172a" />
      <ScrollView contentContainerStyle={styles.container}>
        
        {/* HEADER */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Li-Fi Information System</Text>
          <Text style={styles.headerSubtitle}>Indoor Information Communication</Text>
        </View>

        {/* CONNECTION STATUS BADGE */}
        <View style={styles.statusContainer}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: isConnected ? '#22c55e' : '#ef4444' },
            ]}
          />
          <Text style={styles.statusText}>
            {isConnected ? 'System Connected (Raspberry Pi)' : 'System Disconnected'}
          </Text>
        </View>

        {/* SECTION 1: TRANSMIT DATA */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Transmit Information</Text>
          <Text style={styles.fieldLabel}>Enter message for Li-Fi transmission:</Text>
          
          <TextInput
            style={styles.input}
            placeholder="e.g., Welcome to IoT Lab"
            placeholderTextColor="#94a3b8"
            value={inputText}
            onChangeText={setInputText}
          />

          <TouchableOpacity style={styles.sendButton} onPress={handleSend}>
            <Text style={styles.sendButtonText}>SEND VIA LI-FI</Text>
          </TouchableOpacity>

          <View style={styles.txStatusBox}>
            <Text style={styles.txStatusLabel}>Transmission Status:</Text>
            <Text style={styles.txStatusValue}>{txStatus}</Text>
          </View>
        </View>

        {/* SECTION 2: INDOOR LOCATION CARD */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Indoor Location Information</Text>
          
          <View style={styles.locationHeaderRow}>
            <Text style={styles.locationPin}>📍</Text>
            <Text style={styles.locationName}>{receivedData.name}</Text>
          </View>

          <View style={styles.infoGrid}>
            <View style={styles.infoCol}>
              <Text style={styles.infoLabel}>Room</Text>
              <Text style={styles.infoValue}>{receivedData.room}</Text>
            </View>
            <View style={styles.infoCol}>
              <Text style={styles.infoLabel}>Floor</Text>
              <Text style={styles.infoValue}>{receivedData.floor}</Text>
            </View>
            <View style={styles.infoCol}>
              <Text style={styles.infoLabel}>Beacon ID</Text>
              <Text style={styles.infoValue}>{receivedData.beacon_id}</Text>
            </View>
          </View>

          <View style={styles.announcementBox}>
            <Text style={styles.announcementLabel}>Notice / Instruction:</Text>
            <Text style={styles.announcementText}>{receivedData.message}</Text>
          </View>

          <Text style={styles.footerNote}>Decoded via Li-Fi Optical Receiver</Text>
        </View>

        {/* SECTION 3: SYSTEM METRICS */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Link Telemetry</Text>
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>Last Optical Reception:</Text>
            <Text style={styles.metaValue}>{receivedData.timestamp}</Text>
          </View>
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>Interface:</Text>
            <Text style={styles.metaValue}>Wi-Fi REST $\leftrightarrow$ Li-Fi Link</Text>
          </View>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  container: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 16,
    marginTop: 8,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 2,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1e293b',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },
  statusText: {
    color: '#e2e8f0',
    fontSize: 13,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#38bdf8',
    marginBottom: 12,
  },
  fieldLabel: {
    fontSize: 13,
    color: '#cbd5e1',
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#475569',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: '#f8fafc',
    fontSize: 15,
    marginBottom: 12,
  },
  sendButton: {
    backgroundColor: '#2563eb',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  sendButtonText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 14,
    letterSpacing: 0.5,
  },
  txStatusBox: {
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#334155',
  },
  txStatusLabel: {
    fontSize: 12,
    color: '#94a3b8',
  },
  txStatusValue: {
    fontSize: 13,
    color: '#f1f5f9',
    fontWeight: '500',
    marginTop: 2,
  },
  locationHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  locationPin: {
    fontSize: 20,
    marginRight: 6,
  },
  locationName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f8fafc',
  },
  infoGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#0f172a',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  infoCol: {
    alignItems: 'center',
  },
  infoLabel: {
    fontSize: 11,
    color: '#94a3b8',
    textTransform: 'uppercase',
  },
  infoValue: {
    fontSize: 15,
    fontWeight: '700',
    color: '#38bdf8',
    marginTop: 2,
  },
  announcementBox: {
    backgroundColor: '#0f172a',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  announcementLabel: {
    fontSize: 11,
    color: '#94a3b8',
    marginBottom: 2,
  },
  announcementText: {
    fontSize: 14,
    color: '#e2e8f0',
  },
  footerNote: {
    fontSize: 11,
    color: '#64748b',
    fontStyle: 'italic',
    textAlign: 'right',
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 4,
  },
  metaLabel: {
    fontSize: 13,
    color: '#94a3b8',
  },
  metaValue: {
    fontSize: 13,
    color: '#f1f5f9',
    fontWeight: '500',
  },
});